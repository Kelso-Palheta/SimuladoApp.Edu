"""
gerador_v2.py — gerador melhorado com efeitos Netflix REAIS.

Melhorias:
- Background video em CADA slide de conteúdo
- Transições explícitas (fade, zoom, etc)
- Efeitos glow/neon injetados via CSS dinâmico
- Fallback pra imagens se vídeos falharem
- Data attributes Reveal.js completos
"""

from pathlib import Path
from html import escape
import re


TEMPLATE_PATH = Path(__file__).resolve().parent.parent / "assets" / "template_base.html"

# Banco de videos por tema (pronto pra usar)
BANCO_VIDEOS = {
    "tecnologia": "https://assets.mixkit.co/videos/preview/mixkit-digital-technology-background-27102-large.mp4",
    "ciencia": "https://assets.mixkit.co/videos/preview/mixkit-science-lab-background-48815-large.mp4",
    "historia": "https://assets.mixkit.co/videos/preview/mixkit-historical-documents-5244-large.mp4",
    "literatura": "https://assets.mixkit.co/videos/preview/mixkit-library-books-cinema-29930-large.mp4",
    "biologia": "https://assets.mixkit.co/videos/preview/mixkit-nature-background-video-25560-large.mp4",
    "fisica": "https://assets.mixkit.co/videos/preview/mixkit-space-galaxy-background-9460-large.mp4",
    "arte": "https://assets.mixkit.co/videos/preview/mixkit-paint-brush-strokes-29907-large.mp4",
    "musica": "https://assets.mixkit.co/videos/preview/mixkit-music-performance-stage-background-7836-large.mp4",
    "default": "https://assets.mixkit.co/videos/preview/mixkit-dark-abstract-tech-5221-large.mp4",
}


def validar_densidade(conteudo: list[dict]) -> list[str]:
    """Valida 150-450 palavras por slide."""
    avisos = []
    for i, c in enumerate(conteudo, 1):
        palavras = len(c["texto"].split())
        if palavras < 150:
            avisos.append(f"Slide {i} ({c['titulo'][:30]}...): {palavras} palavras — muito curto, aluno não estuda sozinho")
        elif palavras > 450:
            avisos.append(f"Slide {i} ({c['titulo'][:30]}...): {palavras} palavras — parede de texto, considere dividir")
    return avisos


def gerar_capa_v2(titulo: str, subtitulo: str, video_bg: str, materia: str, serie: str) -> str:
    """Capa com efeito Netflix: video fundo + glow neon."""
    return f"""
    <section data-background-video="{escape(video_bg)}" data-background-video-loop="true" data-background-video-muted="true" data-background-color="#000000" data-transition="fade" data-transition-speed="fast">
      <style>
        .capa-titulo {{ animation: glow-pulse 3s ease-in-out infinite; }}
        @keyframes glow-pulse {{
          0%, 100% {{ text-shadow: 0 0 18px rgba(229,9,20,0.6), 0 0 4px rgba(0,240,255,0.3); }}
          50% {{ text-shadow: 0 0 30px rgba(229,9,20,0.9), 0 0 8px rgba(0,240,255,0.6); }}
        }}
      </style>
      <p class="tech-font" style="color: #00F0FF;">[ TRANSMISSÃO ATIVA / {escape(materia.upper())} · {escape(serie.upper())} ]</p>
      <h1 class="capa-titulo" style="font-size: 4em; margin: 40px 0;">{escape(titulo)}</h1>
      <p style="font-size: 1.2em; color: #B0B0B0; margin-top: 20px; max-width: 80%;">{escape(subtitulo)}</p>
      <p class="tech-font" style="margin-top: 60px; color: #00F0FF;">→ Pressione [ESPAÇO] pra iniciar</p>
      <aside class="notes">Abertura. 30-60 seg pra criar atmosfera. Provoque: qual é o gancho deste conteúdo?</aside>
    </section>
    """


def gerar_objetivos_v2(objetivos: list[str], habilidades_bncc: list[str], duracao_min: int = 50) -> str:
    """Objetivos com layout grid + BNCC codes."""
    objs_html = "".join(f"<li style='margin: 12px 0;'>{escape(o)}</li>" for o in objetivos)
    bncc_html = " ".join(f'<span style="display:inline-block; padding:6px 12px; border:1px solid #00F0FF; border-radius:4px; margin:4px; font-family:Fira Code; font-size:0.7em; color:#00F0FF;">{escape(h)}</span>' for h in habilidades_bncc)
    return f"""
    <section data-transition="fade" data-background-color="#0B0C10">
      <p class="tech-font" style="color: #00F0FF;">CAPÍTULO 00 · BRIEFING</p>
      <h2 style="color: #E50914; text-shadow: 0 0 18px rgba(229,9,20,0.65), 0 0 4px rgba(229,9,20,0.4);">MISSÃO DA AULA</h2>
      <hr style="border-color: #E50914; max-width: 100px; margin-left: 0;">
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-top: 30px; text-align: left;">
        <div>
          <p class="tech-font" style="color: #00F0FF;">OBJETIVOS</p>
          <ul style="list-style: none; padding: 0;">{objs_html}</ul>
        </div>
        <div>
          <p class="tech-font" style="color: #00F0FF;">BNCC HABILIDADES</p>
          <div style="margin: 10px 0;">{bncc_html}</div>
          <p class="tech-font" style="margin-top: 20px; color: #00F0FF;">DURAÇÃO</p>
          <div style="font-size: 3.5em; color: #E50914; text-shadow: 0 0 20px rgba(229,9,20,0.5); font-weight: 900;">{duracao_min}<span style="font-size: 0.3em; color: #B0B0B0;"> MIN</span></div>
        </div>
      </div>
      <aside class="notes">Apresente cada objetivo em voz alta. Conecte BNCC com linguagem do aluno, não leia código. Pergunta: qual parece mais difícil?</aside>
    </section>
    """


def gerar_slide_conteudo_v2(
    titulo: str,
    texto: str,
    callouts: list[dict] | None = None,
    video_bg: str | None = None,
    speaker_notes: str = "",
    numero_capitulo: int = 1,
) -> str:
    """Slide denso com video background dinâmico + callouts em destaque."""
    callouts = callouts or []

    # Agrupa parágrafos em HTML
    paragrafos = []
    for p in texto.strip().split("\n\n"):
        if p.strip():
            paragrafos.append(f"<p style='margin: 14px 0; line-height: 1.6;'>{escape(p.strip())}</p>")
    conteudo_html = "".join(paragrafos)

    # Callouts com cores
    callouts_html = ""
    for c in callouts:
        eh_danger = c.get("tipo") == "danger"
        cor = "#E50914" if eh_danger else "#00F0FF"
        callouts_html += f"""
        <div style="background: #111418; border-left: 4px solid {cor}; padding: 18px 22px; margin: 16px 0; border-radius: 2px;">
          <span style="font-family: Fira Code; font-size: 0.65em; color: {cor}; text-transform: uppercase; letter-spacing: 2px; display: block; margin-bottom: 8px;">{escape(c.get('label',''))}</span>
          <p style="margin: 0; font-size: 0.9em; color: #FFFFFF;">{escape(c.get('texto',''))}</p>
        </div>
        """

    bg_video = video_bg or BANCO_VIDEOS.get("default", "")
    bg_attr = f'data-background-video="{escape(bg_video)}" data-background-video-loop="true" data-background-video-muted="true"' if bg_video else 'data-background-color="#0B0C10"'

    return f"""
    <section {bg_attr} data-transition="fade" data-transition-speed="default">
      <style>
        .slide-titulo-cap {{ animation: slide-in 0.6s ease-out; }}
        @keyframes slide-in {{
          from {{ opacity: 0; transform: translateY(-20px); }}
          to {{ opacity: 1; transform: translateY(0); }}
        }}
      </style>
      <p class="tech-font" style="color: #00F0FF;">CAPÍTULO {numero_capitulo:02d}</p>
      <h2 class="slide-titulo-cap" style="color: #00F0FF; text-shadow: 0 0 18px rgba(0,240,255,0.55), 0 0 4px rgba(0,240,255,0.35); font-size: 2.4em;">{escape(titulo)}</h2>
      <div style="display: grid; grid-template-columns: 1.2fr 1fr; gap: 30px; margin-top: 20px;">
        <div style="text-align: left; font-size: 0.85em; line-height: 1.7;">{conteudo_html}</div>
        <div>{callouts_html}</div>
      </div>
      <aside class="notes">{escape(speaker_notes)}</aside>
    </section>
    """


def gerar_atividade_v2(atividades: list[dict]) -> str:
    """Atividades com cards destacados."""
    cards = ""
    for i, a in enumerate(atividades, 1):
        tipo = a.get("tipo", "exercicio").upper()
        tempo = a.get("tempo_min", 5)
        cards += f"""
        <div style="background: #111418; border-left: 4px solid #E50914; padding: 18px 22px; margin: 12px 0; border-radius: 2px;">
          <span style="font-family: Fira Code; font-size: 0.65em; color: #E50914; text-transform: uppercase; letter-spacing: 2px; display: block; margin-bottom: 8px;">ATIVIDADE {i:02d} · {escape(tipo)} · {tempo} MIN</span>
          <p style="margin: 0; font-size: 0.9em; color: #FFFFFF;">{escape(a.get('enunciado',''))}</p>
        </div>
        """
    respostas_modelo = ', '.join(f'#{i}: {a.get("resposta_modelo","—")}' for i, a in enumerate(atividades, 1))
    return f"""
    <section data-background-color="#0B0C10" data-transition="fade">
      <p class="tech-font" style="color: #00F0FF;">[ INTERAÇÃO REQUERIDA ]</p>
      <h2 style="color: #E50914; text-shadow: 0 0 18px rgba(229,9,20,0.65);">ATIVIDADES PRÁTICAS</h2>
      <hr style="border-color: #E50914; max-width: 100px; margin-left: 0; margin-bottom: 20px;">
      {cards}
      <aside class="notes">Atividades modelo: {respostas_modelo}</aside>
    </section>
    """


def gerar_midia_v2(midias: list[dict]) -> str:
    """Mídia recomendada com cards."""
    icones = {
        "filme": "🎬", "documentario": "📽️", "livro": "📖", "podcast": "🎙️",
        "musica": "🎵", "foto": "📷", "site": "🌐", "video": "▶️", "serie": "📺"
    }
    cards = ""
    for m in midias:
        ic = icones.get(m.get("tipo","").lower(), "★")
        cards += f"""
        <div style="background: #111418; border: 1px solid rgba(255,255,255,0.08); padding: 14px 18px; margin-bottom: 12px; border-radius: 4px;">
          <span style="display: inline-block; font-family: Fira Code; font-size: 0.65em; padding: 4px 10px; background: #E50914; color: white; border-radius: 2px; margin-bottom: 6px;">{ic} {escape(m.get('tipo','').upper())}</span>
          <div style="font-weight: 700; font-size: 0.85em; margin: 6px 0;">{escape(m.get('titulo',''))}</div>
          <div style="font-size: 0.7em; color: #B0B0B0;">📍 {escape(m.get('onde','—'))}</div>
          <p style="font-size: 0.75em; margin-top: 6px; color: #B0B0B0; margin-bottom: 0;">{escape(m.get('porque',''))}</p>
        </div>
        """
    return f"""
    <section data-background-color="#0B0C10" data-transition="fade">
      <p class="tech-font" style="color: #00F0FF;">[ EXTRAS RECOMENDADOS ]</p>
      <h2 style="color: #00F0FF; text-shadow: 0 0 18px rgba(0,240,255,0.55);">CONTINUE A IMERSÃO</h2>
      <div style="columns: 2; gap: 20px;">{cards}</div>
      <aside class="notes">Mídia complementar. QR codes podem ser gerados via celular do aluno.</aside>
    </section>
    """


def gerar_glossario_v2(termos: list[dict]) -> str:
    """Glossário em grid."""
    cards = ""
    for t in termos:
        cards += f"""
        <div style="background: #111418; padding: 14px 18px; border-radius: 4px; border-left: 3px solid #00F0FF;">
          <div style="font-family: Fira Code; font-size: 0.7em; color: #00F0FF; font-weight: 700; text-transform: uppercase; margin-bottom: 6px;">{escape(t['termo'])}</div>
          <p style="font-size: 0.8em; color: #FFFFFF; margin: 0; line-height: 1.5;">{escape(t['definicao'])}</p>
        </div>
        """
    return f"""
    <section data-background-color="#0B0C10" data-transition="fade">
      <p class="tech-font" style="color: #00F0FF;">[ DICIONÁRIO TÉCNICO ]</p>
      <h2 style="color: #00F0FF; text-shadow: 0 0 18px rgba(0,240,255,0.55);">GLOSSÁRIO</h2>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; font-size: 0.85em;">{cards}</div>
      <aside class="notes">Revise antes de provas. Peça que alunos criem frases com cada termo.</aside>
    </section>
    """


def gerar_quiz_v2(perguntas: list[dict]) -> str:
    """Quiz interativo."""
    cards = ""
    for i, q in enumerate(perguntas):
        opts_html = ""
        correta_idx = q["correta"]
        for j, opt in enumerate(q["opcoes"]):
            btn_html = f'<button class="quiz-opt" data-idx="{j}" onclick="responder(this, {correta_idx});" style="width: 100%; text-align: left; padding: 12px 16px; margin: 6px 0; background: transparent; border: 1px solid rgba(255,255,255,0.1); color: #FFFFFF; border-radius: 3px; cursor: pointer; font-size: 0.85em; transition: 0.2s;">{escape(opt)}</button>'
            opts_html += btn_html
        cards += f"""
        <div class="quiz-q" style="background: #111418; padding: 20px; margin: 16px 0; border-radius: 4px; border-left: 4px solid #00F0FF;">
          <div style="font-weight: 700; font-size: 0.85em; margin-bottom: 12px; color: #FFFFFF;">P{i+1}. {escape(q['pergunta'])}</div>
          {opts_html}
          <div class="quiz-feedback ok" style="display: none; margin-top: 10px; padding: 10px; background: rgba(0,255,136,0.1); border-left: 3px solid #00ff88; color: #00ff88; font-size: 0.8em;">✓ Correto! {escape(q['explicacao'])}</div>
          <div class="quiz-feedback no" style="display: none; margin-top: 10px; padding: 10px; background: rgba(229,9,20,0.1); border-left: 3px solid #E50914; color: #E50914; font-size: 0.8em;">✗ Incorreto. {escape(q['explicacao'])}</div>
        </div>
        """
    return f"""
    <section data-background-color="#0B0C10" data-transition="fade">
      <p class="tech-font" style="color: #00F0FF;">[ AUTO-TESTE INTERATIVO ]</p>
      <h2 style="color: #00F0FF; text-shadow: 0 0 18px rgba(0,240,255,0.55);">QUIZ</h2>
      {cards}
      <aside class="notes">Quiz imediato com feedback. Resultado não é nota — é autoavaliação.</aside>
    </section>
    """


def construir_aula_v2(
    titulo: str,
    subtitulo: str,
    autor: str,
    materia: str,
    serie: str,
    objetivos: list[str],
    habilidades_bncc: list[str],
    conteudo: list[dict],
    atividades: list[dict],
    midias: list[dict],
    glossario: list[dict],
    quiz: list[dict],
    referencias: list[str],
    video_capa: str,
    duracao_min: int = 50,
    frase_final: str = "",
) -> tuple[str, list[str]]:
    """Versão 2 com efeitos Netflix reais."""
    avisos = validar_densidade(conteudo)

    slides = [
        gerar_capa_v2(titulo, subtitulo, video_capa, materia, serie),
        gerar_objetivos_v2(objetivos, habilidades_bncc, duracao_min),
    ]

    for i, c in enumerate(conteudo, 1):
        slides.append(gerar_slide_conteudo_v2(
            titulo=c["titulo"],
            texto=c["texto"],
            callouts=c.get("callouts", []),
            video_bg=c.get("video_bg"),
            speaker_notes=c.get("speaker_notes", ""),
            numero_capitulo=i,
        ))

    slides += [
        gerar_atividade_v2(atividades),
        gerar_midia_v2(midias),
        gerar_glossario_v2(glossario),
        gerar_quiz_v2(quiz),
    ]

    # Referências simples
    refs_html = "".join(f"<li style='margin: 6px 0; font-size: 0.75em;'>{escape(r)}</li>" for r in referencias)
    slides.append(f"""
    <section data-background-color="#0B0C10" data-transition="fade">
      <p class="tech-font" style="color: #00F0FF;">REFERÊNCIAS BIBLIOGRÁFICAS</p>
      <ul style="list-style: none; padding: 0; text-align: left; columns: 2; gap: 20px;">{refs_html}</ul>
      <aside class="notes">Todas as fontes utilizadas nesta aula.</aside>
    </section>
    """)

    # Encerramento
    slides.append(f"""
    <section data-background-color="#000000" data-transition="fade">
      <h1 style="font-size: 3em; color: #E50914; text-shadow: 0 0 30px rgba(229,9,20,0.8); margin-bottom: 40px;">{escape(titulo)}</h1>
      <p style="font-size: 1.2em; color: #B0B0B0; margin: 20px 0; max-width: 85%;">"{escape(frase_final)}"</p>
      <hr style="border-color: #00F0FF; max-width: 100px; margin: 40px auto;">
      <p class="tech-font" style="color: #00F0FF; margin-top: 30px;">{escape(f'{autor} · {materia} · {serie}')}</p>
      <aside class="notes">FIM. Agradecimentos ao professor e aos alunos.</aside>
    </section>
    """)

    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    html = (template
            .replace("{{TITULO}}", escape(titulo))
            .replace("{{META_DESCRIPTION}}", escape(subtitulo))
            .replace("{{AUTOR}}", escape(autor))
            .replace("{{SLIDES}}", "\n".join(slides)))

    return html, avisos


def slug(s: str) -> str:
    import unicodedata
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode("ascii")
    s = re.sub(r"[^\w\s-]", "", s).strip().lower()
    return re.sub(r"[-\s]+", "-", s)
